package ac.grim.grimac.platform.bukkit.events;

import ac.grim.grimac.GrimAPI;
import ac.grim.grimac.checks.impl.combat.AutoTotem;
import ac.grim.grimac.player.GrimPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;

/**
 * يستمع لـ EntityResurrectEvent لما يُفعّل اللاعب الـ totem
 * ويبلّغ AutoTotem check عشان يبدأ يراقب وقت الاستبدال
 */
public class TotemEvent implements Listener {

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTotemUse(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player)) return;

        Player bukkitPlayer = (Player) event.getEntity();
        GrimPlayer player = GrimAPI.INSTANCE.getPlayerDataManager().getPlayer(bukkitPlayer);
        if (player == null) return;

        // أبلّغ الـ check إن الـ totem اشتغل
        player.checkManager.get(AutoTotem.class).onTotemUsed();
    }
}
