package ac.grim.grimac.checks.impl.aim;

import ac.grim.grimac.api.config.ConfigManager;
import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.checks.type.RotationListener;
import ac.grim.grimac.player.GrimPlayer;
import ac.grim.grimac.utils.anticheat.update.RotationUpdate;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Triggerbot Detection
 * يكشف Triggerbot عبر تحليل timing الضربات
 * Triggerbot يضرب فور ما يكون الهدف في الـ crosshair بوقت أقل من البشر
 *
 * الإصلاحات من النسخة السابقة:
 * 1. THREAD SAFETY: hadRotationChange الآن volatile — process() وonAttack()
 *    يعملان على نفس pipeline عادةً لكن volatile ضرورية للـ memory visibility
 * 2. TIMESTAMP: نستخدم System.nanoTime() للـ intervals بدل currentTimeMillis()
 *    لأن currentTimeMillis() دقتها ~10-15ms على Windows وهذا يؤثر على
 *    threshold الـ 100ms بشكل كبير
 * 3. COMPAT: إضافة استثناء لـ 1.8 clients (attack timing مختلف)
 * 4. LOGIC: interval ceiling رُفع من 600ms إلى 2000ms لاستيعاب لاعبين بطيئين
 *    مع الإبقاء على الـ fast-attack window ضيقاً
 */
@CheckData(name = "Triggerbot", stableKey = "grim.aim.triggerbot", description = "Detected suspicious attack timing consistent with Triggerbot")
public class Triggerbot extends Check implements RotationListener {

    private int sampleSize;
    private long minHumanReactionMs;
    private double maxTimingConsistency;
    private double maxCoefficientVariation;

    private final Deque<Long> fastAttackTimings = new ArrayDeque<>();
    private final Deque<Long> intervalHistory   = new ArrayDeque<>();

    // نستخدم nanoTime — أدق من currentTimeMillis على كل نظام تشغيل
    private long lastAttackNano = 0L;

    // volatile: process() يكتب، onAttack() يقرأ — نفس thread عادةً لكن volatile آمن
    private volatile boolean hadRotationChange = false;

    public Triggerbot(GrimPlayer player) {
        super(player);
    }

    @Override
    public void onReload(@NotNull ConfigManager config) {
        this.sampleSize              = config.getIntElse("Triggerbot.sample-size", 15);
        this.minHumanReactionMs      = config.getIntElse("Triggerbot.min-human-reaction-ms", 120);
        this.maxTimingConsistency    = config.getDoubleElse("Triggerbot.max-timing-consistency", 0.75);
        this.maxCoefficientVariation = config.getDoubleElse("Triggerbot.max-coefficient-variation", 0.12);
    }

    @Override
    public void process(final RotationUpdate rotationUpdate) {
        hadRotationChange = Math.abs(rotationUpdate.deltaYaw())   > 0.1f
                         || Math.abs(rotationUpdate.deltaPitch()) > 0.1f;
    }

    public void onAttack() {
        // 1.8: attack timing مختلف بسبب انعدام cooldown
        if (player.getClientVersion().isOlderThanOrEquals(ClientVersion.V_1_8)) return;

        if (player.packetStateData.lastPacketWasTeleport) {
            lastAttackNano = System.nanoTime();
            return;
        }
        if (player.compensatedEntities.self.getRiding() != null) {
            lastAttackNano = System.nanoTime();
            return;
        }

        long nowNano = System.nanoTime();

        if (lastAttackNano > 0L) {
            // تحويل nano → ms بدقة أعلى من currentTimeMillis
            long intervalMs = (nowNano - lastAttackNano) / 1_000_000L;

            // ضربة سريعة جداً بعد تغيير rotation = مشبوه
            if (hadRotationChange && intervalMs > 0 && intervalMs < minHumanReactionMs) {
                if (fastAttackTimings.size() >= sampleSize) fastAttackTimings.poll();
                fastAttackTimings.add(intervalMs);
            }

            // سجّل كل intervals المعقولة (رُفع السقف من 600ms → 2000ms)
            if (intervalMs > 0 && intervalMs < 2000L) {
                if (intervalHistory.size() >= sampleSize) intervalHistory.poll();
                intervalHistory.add(intervalMs);
            }
        }

        lastAttackNano = nowNano;

        if (fastAttackTimings.size() < sampleSize / 2) return;
        if (intervalHistory.size() < sampleSize)       return;

        // احسب ثبات الـ intervals
        long[] intervals = intervalHistory.stream().mapToLong(Long::longValue).toArray();
        double mean = 0;
        for (long i : intervals) mean += i;
        mean /= intervals.length;

        if (mean <= 0) return;

        double variance = 0;
        for (long i : intervals) variance += Math.pow(i - mean, 2);
        variance /= intervals.length;
        double stdDev = Math.sqrt(variance);

        // Coefficient of Variation: منخفض = ضرب ثابت جداً = روبوت
        double cv = stdDev / mean;

        // نسبة الضربات السريعة
        double fastAttackRate = (double) fastAttackTimings.size() / sampleSize;

        if (cv < maxCoefficientVariation && fastAttackRate > maxTimingConsistency) {
            if (flag("avgInterval=" + String.format("%.0f", mean) + "ms"
                    + " cv="          + String.format("%.3f", cv)
                    + " fastRate="    + String.format("%.2f", fastAttackRate))) {
                fastAttackTimings.clear();
                intervalHistory.clear();
            }
        }
    }
}
