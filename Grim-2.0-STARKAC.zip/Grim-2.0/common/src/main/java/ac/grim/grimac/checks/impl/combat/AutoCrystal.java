package ac.grim.grimac.checks.impl.combat;

import ac.grim.grimac.api.config.ConfigManager;
import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.checks.type.PacketCheck;
import ac.grim.grimac.player.GrimPlayer;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes;
import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.player.InteractionHand;
import com.github.retrooper.packetevents.util.Vector3d;
import com.github.retrooper.packetevents.util.Vector3i;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientAttack;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerBlockPlacement;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * AutoCrystal Detection
 *
 * يكشف الكلاينتات اللي تحط الكريستال وتكسره تلقائياً بسرعة أعلى من البشر.
 *
 * طريقة الكشف:
 * 1. نسجّل لما اللاعب يحط END_CRYSTAL (مكان + وقت).
 * 2. لما السيرفر يرسل spawn للكريستال بنفس المكان، نسجّل وقت الإرسال.
 * 3. لما اللاعب يضرب هذا الكريستال، نحسب وقت رد الفعل:
 *       reaction = (وقت وصول الضربة - وقت إرسال الـ spawn) - البنق
 * 4. نفلق في حالتين:
 *    أ) رد الفعل أقل من الحد البشري عدة مرات متتالية
 *    ب) رد الفعل ثابت بشكل غير بشري (انحراف معياري صغير جداً)
 *
 * ملاحظة: نطرح البنق الأصغر (transaction/keepalive) لتقليل الفلاقات الكاذبة
 * عند تذبذب النت.
 */
@CheckData(name = "AutoCrystal", stableKey = "grim.combat.autocrystal", description = "Detected crystal break faster or more consistent than human reaction time")
public class AutoCrystal extends Check implements PacketCheck {

    private static final long PLACE_VALID_NANOS = 3_000_000_000L;   // الكريستال لازم يظهر خلال 3 ثواني من الوضع
    private static final long SPAWN_VALID_NANOS = 3_000_000_000L;   // ضربة بعد 3 ثواني ما تُحسب
    private static final long SAMPLE_GAP_NANOS = 10_000_000_000L;   // فجوة 10 ثواني = نبدأ عينات جديدة
    private static final int MAX_TRACKED_SPAWNS = 16;

    private long minHumanReactionMs;
    private long instantFlagMs;
    private int sampleSize;
    private double maxStdDevMs;
    private long consistentAvgMs;

    // مكان ووقت آخر كريستال وضعه اللاعب
    private long lastPlaceNano = 0L;
    private double placeX, placeY, placeZ;

    // entityId -> وقت إرسال الـ spawn (nanoTime)
    private final Map<Integer, Long> spawnTimes = new HashMap<>();
    private final Deque<Double> reactions = new ArrayDeque<>();
    private long lastSampleNano = 0L;

    public AutoCrystal(GrimPlayer player) {
        super(player);
    }

    @Override
    public void onReload(@NotNull ConfigManager config) {
        this.minHumanReactionMs = config.getIntElse("AutoCrystal.min-human-reaction-ms", 60);
        this.instantFlagMs = config.getIntElse("AutoCrystal.instant-flag-ms", 5);
        this.sampleSize = Math.max(3, config.getIntElse("AutoCrystal.sample-size", 5));
        this.maxStdDevMs = config.getDoubleElse("AutoCrystal.max-std-dev-ms", 12.0);
        this.consistentAvgMs = config.getIntElse("AutoCrystal.consistent-avg-ms", 120);
    }

    @Override
    public void onPacketReceive(final PacketReceiveEvent event) {
        if (player.disableGrim) return;

        if (event.getPacketType() == PacketType.Play.Client.PLAYER_BLOCK_PLACEMENT) {
            WrapperPlayClientPlayerBlockPlacement packet = new WrapperPlayClientPlayerBlockPlacement(event);
            InteractionHand hand = packet.getHand();
            if (hand == null) return;
            if (player.inventory.getItemInHand(hand).getType() != ItemTypes.END_CRYSTAL) return;

            Vector3i pos = packet.getBlockPosition();
            // الكريستال يظهر فوق البلوك المضغوط عليه
            this.placeX = pos.getX() + 0.5;
            this.placeY = pos.getY() + 1.0;
            this.placeZ = pos.getZ() + 0.5;
            this.lastPlaceNano = System.nanoTime();
            return;
        }

        if (event.getPacketType() == PacketType.Play.Client.ATTACK) {
            WrapperPlayClientAttack packet = new WrapperPlayClientAttack(event);
            onAttack(packet.getEntityId());
        } else if (event.getPacketType() == PacketType.Play.Client.INTERACT_ENTITY) {
            WrapperPlayClientInteractEntity packet = new WrapperPlayClientInteractEntity(event);
            if (packet.getAction() == WrapperPlayClientInteractEntity.InteractAction.ATTACK) {
                onAttack(packet.getEntityId());
            }
        }
    }

    @Override
    public void onPacketSend(final PacketSendEvent event) {
        if (event.getPacketType() != PacketType.Play.Server.SPAWN_ENTITY) return;
        if (lastPlaceNano == 0L) return;

        WrapperPlayServerSpawnEntity spawn = new WrapperPlayServerSpawnEntity(event);
        if (spawn.getEntityType() != EntityTypes.END_CRYSTAL) return;

        long now = System.nanoTime();
        if (now - lastPlaceNano > PLACE_VALID_NANOS) return;

        // لازم يكون الكريستال في نفس المكان اللي وضعه فيه اللاعب
        Vector3d pos = spawn.getPosition();
        if (Math.abs(pos.getX() - placeX) > 1.5
                || Math.abs(pos.getZ() - placeZ) > 1.5
                || Math.abs(pos.getY() - placeY) > 1.5) return;

        if (spawnTimes.size() >= MAX_TRACKED_SPAWNS) spawnTimes.clear();
        spawnTimes.put(spawn.getEntityId(), now);
    }

    private void onAttack(int entityId) {
        Long spawnNano = spawnTimes.remove(entityId);
        if (spawnNano == null) return; // مو كريستال وضعه هذا اللاعب

        long now = System.nanoTime();
        long elapsedNanos = now - spawnNano;
        if (elapsedNanos > SPAWN_VALID_NANOS) return;

        // نطرح البنق الأصغر عشان ما نظلم اللاعب لو تذبذب النت
        int pingMs = Math.max(0, Math.min(player.getTransactionPing(), player.getKeepAlivePing()));
        double reactionMs = elapsedNanos / 1_000_000.0 - pingMs;

        if (now - lastSampleNano > SAMPLE_GAP_NANOS) reactions.clear();
        lastSampleNano = now;

        reactions.addLast(reactionMs);
        while (reactions.size() > sampleSize) reactions.pollFirst();

        // فلاق فوري: أسرع من أي رد فعل ممكن
        if (reactionMs < instantFlagMs) {
            if (flag("instant reaction=" + fmt(reactionMs) + "ms ping=" + pingMs + "ms")) reactions.clear();
            return;
        }

        if (reactions.size() < sampleSize) return;

        double sum = 0;
        int fast = 0;
        for (double r : reactions) {
            sum += r;
            if (r < minHumanReactionMs) fast++;
        }
        double avg = sum / reactions.size();

        // أ) كل العينات أسرع من البشر
        if (fast >= sampleSize) {
            if (flag("fast avg=" + fmt(avg) + "ms samples=" + reactions.size() + " ping=" + pingMs + "ms")) reactions.clear();
            return;
        }

        // ب) ثابت بشكل غير بشري
        double variance = 0;
        for (double r : reactions) variance += (r - avg) * (r - avg);
        double stdDev = Math.sqrt(variance / reactions.size());

        if (avg < consistentAvgMs && stdDev < maxStdDevMs) {
            if (flag("consistent avg=" + fmt(avg) + "ms std=" + fmt(stdDev) + "ms ping=" + pingMs + "ms")) reactions.clear();
        }
    }

    private static String fmt(double v) {
        return String.format("%.1f", v);
    }
}
