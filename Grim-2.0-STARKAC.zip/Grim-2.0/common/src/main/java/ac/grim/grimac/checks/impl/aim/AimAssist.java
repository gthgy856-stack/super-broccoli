package ac.grim.grimac.checks.impl.aim;

import ac.grim.grimac.api.config.ConfigManager;
import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.checks.type.RotationListener;
import ac.grim.grimac.player.GrimPlayer;
import ac.grim.grimac.utils.anticheat.update.RotationUpdate;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * AimAssist Detection
 * يكشف AimAssist عبر تحليل نسبة pitch/yaw أثناء الضرب
 * الـ AimAssist يحرك الكاميرا بشكل روبوتي ثابت نحو الهدف
 *
 * الإصلاحات من النسخة السابقة:
 * 1. LOGIC: ratioVarianceMax كانت تُستخدم لـ stdDev وأيضاً كـ tolerance —
 *    الآن منفصلتان: variance-max (stdDev) و tolerance-per-sample (proximity)
 * 2. COMPAT: إضافة استثناء لـ 1.8 clients (حركة مختلفة بطبيعتها)
 * 3. THREAD: attackTicks الآن volatile لأن onAttack() قد يأتي من packet thread آخر
 * 4. RANGE: تضييق نطاق ratio المقبول من (0.05-15) إلى (0.1-10) لتقليل noise
 */
@CheckData(name = "AimAssist", stableKey = "grim.aim.aimassist", description = "Detected robotic aim movement consistent with AimAssist")
public class AimAssist extends Check implements RotationListener {

    private int sampleSize;
    private double consistencyThreshold;
    // أقصى stdDev مسموح — أقل = أصرم على الـ aim بوتات
    private double varianceMax;
    // أقصى بُعد عن الـ mean يُعدّ "ثابتاً" لكل sample
    private double tolerancePerSample;

    private final Deque<Double> ratioHistory = new ArrayDeque<>();

    // volatile لأن onAttack() يأتي من packet pipeline
    private volatile int attackTicks = 0;

    public AimAssist(GrimPlayer player) {
        super(player);
    }

    @Override
    public void onReload(@NotNull ConfigManager config) {
        this.sampleSize           = config.getIntElse("AimAssist.sample-size", 20);
        this.consistencyThreshold = config.getDoubleElse("AimAssist.consistency-threshold", 0.82);
        this.varianceMax          = config.getDoubleElse("AimAssist.variance-max", 0.07);
        // قيمة منفصلة — كانت مشتركة مع varianceMax في النسخة السابقة
        this.tolerancePerSample   = config.getDoubleElse("AimAssist.tolerance-per-sample", 0.10);
    }

    @Override
    public void process(final RotationUpdate rotationUpdate) {
        // 1.8 clients: حركة الـ pitch/yaw مختلفة جذرياً بسبب float precision
        if (player.getClientVersion().isOlderThanOrEquals(ClientVersion.V_1_8)) return;

        if (player.packetStateData.lastPacketWasTeleport) return;
        if (player.compensatedEntities.self.getRiding() != null) return;
        if (player.isInBed) return;

        float deltaYaw   = Math.abs(rotationUpdate.deltaYaw());
        float deltaPitch = Math.abs(rotationUpdate.deltaPitch());

        // تجاهل micro-movements
        if (deltaYaw < 0.01f && deltaPitch < 0.01f) return;

        // سجّل نسبة pitch/yaw فقط لما في حركة yaw واضحة
        if (deltaYaw > 0.05f) {
            double ratio = deltaPitch / deltaYaw;

            // نطاق منطقي — أضيق من السابق (0.05-15) لتقليل noise
            if (ratio >= 0.1 && ratio <= 10.0) {
                if (ratioHistory.size() >= sampleSize) ratioHistory.poll();
                ratioHistory.add(ratio);
            }
        }

        if (ratioHistory.size() < sampleSize) return;

        // لا تفحص إلا لما اللاعب يضرب
        if (attackTicks <= 0) return;
        attackTicks = Math.max(0, attackTicks - 1);

        double[] ratioArr = ratioHistory.stream().mapToDouble(Double::doubleValue).toArray();

        double mean = 0;
        for (double r : ratioArr) mean += r;
        mean /= ratioArr.length;

        // نطاق منطقي مُحدَّث
        if (mean < 0.1 || mean > 10.0) return;

        double variance = 0;
        for (double r : ratioArr) variance += Math.pow(r - mean, 2);
        variance /= ratioArr.length;
        double stdDev = Math.sqrt(variance);

        // stdDev منخفض = حركة روبوتية
        if (stdDev >= varianceMax) return;

        // احسب نسبة الـ samples القريبة من الـ mean بـ tolerancePerSample (منفصلة الآن)
        long consistentCount = 0;
        for (double r : ratioArr) {
            if (Math.abs(r - mean) < tolerancePerSample) consistentCount++;
        }
        double consistencyRate = (double) consistentCount / ratioArr.length;

        if (consistencyRate > consistencyThreshold) {
            if (flag("ratio=" + String.format("%.3f", mean)
                    + " stdDev=" + String.format("%.4f", stdDev)
                    + " consistency=" + String.format("%.2f", consistencyRate))) {
                ratioHistory.clear();
            }
        }
    }

    public void onAttack() {
        attackTicks = 10;
    }
}
