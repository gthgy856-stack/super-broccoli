package ac.grim.grimac.checks.impl.combat;

import ac.grim.grimac.api.config.ConfigManager;
import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.checks.type.PacketCheck;
import ac.grim.grimac.player.GrimPlayer;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.item.ItemStack;
import com.github.retrooper.packetevents.protocol.item.type.ItemTypes;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientSetCreativeSlot;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientClickWindow;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * AutoTotem Detection
 *
 * AutoTotem يستبدل الـ totem في الـ offhand تلقائياً بعد استخدامه
 * بسرعة أقل بكثير من رد فعل البشر الطبيعي (< 150ms)
 *
 * الإصلاحات من النسخة السابقة:
 * 1. BUG: waitingForReequip كانت تُضبط على false لما يفرغ الـ offhand (عكس المطلوب)
 * 2. RACE CONDITION: onTotemUsed() يأتي من Bukkit thread بينما onPacketReceive()
 *    على packet thread — الآن نستخدم AtomicLong/AtomicBoolean
 * 3. LOGIC: الـ SWAP_ITEM_WITH_OFFHAND لا يُمثّل عملية استبدال الـ totem فعلياً —
 *    الآن نراقب CLICK_WINDOW (نقل item لـ offhand slot = slot 45)
 *
 * طريقة الكشف:
 * 1. onTotemUsed() يُستدعى من TotemEvent (Bukkit thread) → يُسجّل وقت الاستخدام
 * 2. نراقب CLICK_WINDOW أو SET_CREATIVE_SLOT للـ offhand slot (45)
 * 3. لو وصل totem للـ offhand بعد وقت أقل من minHumanReaction → flag
 */
@CheckData(name = "AutoTotem", stableKey = "grim.combat.autototem", description = "Detected totem re-equip faster than human reaction time")
public class AutoTotem extends Check implements PacketCheck {

    private static final int OFFHAND_SLOT = 45;

    // Thread-safe لأن onTotemUsed() يأتي من Bukkit thread
    private final AtomicLong totemUsedTime = new AtomicLong(-1L);
    private final AtomicBoolean waitingForReequip = new AtomicBoolean(false);

    private long minHumanReaction;
    private int sampleSize;
    private long instantFlagMs;

    private final Deque<Long> fastReequipTimes = new ArrayDeque<>();

    public AutoTotem(GrimPlayer player) {
        super(player);
    }

    @Override
    public void onReload(@NotNull ConfigManager config) {
        this.minHumanReaction = config.getIntElse("AutoTotem.min-human-reaction-ms", 150);
        this.sampleSize = config.getIntElse("AutoTotem.sample-size", 3);
        this.instantFlagMs = config.getIntElse("AutoTotem.instant-flag-ms", 30);
    }

    @Override
    public void onPacketReceive(final PacketReceiveEvent event) {
        // نتحقق من ClickWindow: لازم الـ totem "يوصل فعلاً" لـ slot 45 (offhand)
        // قبل كان يحسب أي كليك يرفع totem (مثل أول خطوة من استبدال عادي) وهذا سبب الـ false
        if (event.getPacketType() == PacketType.Play.Client.CLICK_WINDOW) {
            if (!waitingForReequip.get()) return;

            WrapperPlayClientClickWindow packet = new WrapperPlayClientClickWindow(event);

            if (packet.getWindowId() != 0) return; // inventory اللاعب فقط

            // الـ slots اللي غيّرها الكليك حسب ادعاء الكلاينت (1.17+)
            Optional<Map<Integer, ItemStack>> changed = packet.getSlots();
            if (changed.isEmpty()) return; // كلاينت قديم: نتجاهل بدل ما نغلط

            ItemStack offhandItem = changed.get().get(OFFHAND_SLOT);
            if (offhandItem == null || offhandItem.isEmpty()) return;

            if (offhandItem.getType() == ItemTypes.TOTEM_OF_UNDYING) {
                checkReequipTime();
            }
        }

        // Creative mode: SET_CREATIVE_SLOT مباشرة على slot 45
        if (event.getPacketType() == PacketType.Play.Client.SET_CREATIVE_SLOT) {
            if (!waitingForReequip.get()) return;

            WrapperPlayClientSetCreativeSlot packet = new WrapperPlayClientSetCreativeSlot(event);
            if (packet.getSlot() != OFFHAND_SLOT) return;

            ItemStack item = packet.getItemStack();
            if (item == null || item.isEmpty()) return;

            if (item.getType() == ItemTypes.TOTEM_OF_UNDYING) {
                checkReequipTime();
            }
        }
    }

    private void checkReequipTime() {
        long usedAt = totemUsedTime.get();
        if (usedAt < 0) return;

        long now = System.currentTimeMillis();
        long reequipTime = now - usedAt;

        // reset الحالة فوراً (atomic)
        if (!waitingForReequip.compareAndSet(true, false)) return;
        totemUsedTime.set(-1L);

        // تجاهل قيم غير منطقية
        if (reequipTime <= 0 || reequipTime > 10_000L) return;

        if (reequipTime < minHumanReaction) {
            if (fastReequipTimes.size() >= sampleSize) fastReequipTimes.poll();
            fastReequipTimes.add(reequipTime);

            // فلاق فوري لو أسرع من 50ms أو تكرر sampleSize مرات
            if (fastReequipTimes.size() >= sampleSize || reequipTime < instantFlagMs) {
                long avgTime = fastReequipTimes.stream()
                        .mapToLong(Long::longValue).sum() / fastReequipTimes.size();

                if (flag("reequipMs=" + reequipTime + "ms avg=" + avgTime + "ms")) {
                    fastReequipTimes.clear();
                }
            }
        } else {
            // استبدال طبيعي — نظّف السجل
            fastReequipTimes.clear();
        }
    }

    /**
     * يُستدعى من TotemEvent (Bukkit thread) لما يُفعّل اللاعب الـ totem.
     * نستخدم AtomicLong/AtomicBoolean لأن هذا يأتي من thread مختلف.
     */
    public void onTotemUsed() {
        // الوقت الفعلي نسجله لما نرسل packet الأنيميشن للاعب (onPacketSend)
        // لأن event الـ Bukkit يجي قبل ما اللاعب يشوف الـ pop (خصوصاً مع lag السيرفر)
        waitingForReequip.set(true);
        totemUsedTime.set(-1L);
        fastReequipTimes.clear();
    }

    @Override
    public void onPacketSend(final PacketSendEvent event) {
        if (event.getPacketType() != PacketType.Play.Server.ENTITY_STATUS) return;

        WrapperPlayServerEntityStatus status = new WrapperPlayServerEntityStatus(event);
        // status 35 = أنيميشن الـ totem
        if (status.getStatus() != 35 || status.getEntityId() != player.entityID) return;

        totemUsedTime.set(System.currentTimeMillis());
        waitingForReequip.set(true);
    }
}
